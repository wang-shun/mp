# 安装influxdb
echo -n [info]安装influxdb............
rpm -ivh influxdb-1.3.2.x86_64.rpm
echo done

# 安装kapactior
echo -n [info]安装kapactior.............
rpm -ivh kapacitor-1.3.1.x86_64.rpm
echo done

# influxdb 配置
# 设置数据目录，缺省为/var/influxdb
DATA_DIR=/var/influxdb
OPTION=n
while [ 1 -eq 1 ]
do
  echo "输入数据目录，缺省为/var/influxdb，不修改请按回车"
  read DATA_DIR
  if [[ "$DATA_DIR" = "" ]];then
     DATA_DIR="/var/influxdb"
     break;
  fi
done

# 替换配置文件中目录路径
sed `echo 's#/var/lib/influxdb#'$DATA_DIR'#g'` influxdb.conf > /etc/influxdb/influxdb.conf

# 创建目录
if [[ ! -e $DATA_DIR ]];then
  mkdir -p $DATA_DIR
fi
chown -R influxdb:influxdb $DATA_DIR

pgrep influxd >/dev/null 2>&1
if [[ "$?" = "0" ]]; then
  service influxdb stop
fi

# 启动influxdb
service influxdb start

# 检测并等待启动完成
while [ 1 -eq 1 ]
do
  influx -execute 'show databases' >/dev/null 2>&1
  if [[ "$?" = "0" ]];then
    break
  fi
done

# 初始化数据库及用户
echo -n [info]初始化数据库及用户..............
influx -execute 'CREATE DATABASE "mydb"'
influx -execute "CREATE USER admin WITH PASSWORD 'FHuma025' WITH ALL PRIVILEGES"
influx -execute "CREATE USER metric WITH PASSWORD 'FHuma025'"
influx -execute "GRANT ALL on mydb to metric"
echo done

# 修改配置，打开Auth
sed -i 's/auth-enabled = false/auth-enabled = true/g' /etc/influxdb/influxdb.conf

# 重新启动服务
service influxdb restart

# 校验influxdb

# kapactior 配置
MAIL_HOST=
MAIL_PORT=
MAIL_USER=
MAIL_PASSWORD=
MAIL_FROM=
SSL_V=Y

# stdin input function, $desc, $default
readin() {
  while [ 1 -eq 1 ]
  do
    echo $1
    if [[ -n $2 ]]; then
       echo "缺省为$2，不修改请按回车"
    fi

    read TMP_INPUT
    if [[ "$TMP_INPUT" = "" && "$2" != "" ]];then
       TMP_INPUT=$2
    fi

    if [[ -n "$TMP_INPUT" ]]; then
       readin=$TMP_INPUT
       break
    fi
  done
}

readin "输入smtp服务主机地址，ip或者域名" ""
MAIL_HOST=$readin

readin "输入smtp服务端口" 25
MAIL_PORT=$readin

readin "输入smtp服务用户" ""
MAIL_USER=$readin

readin "输入smtp服务密码" ""
MAIL_PASSWORD=$readin

readin "输入smtp发送用户邮箱" ""
MAIL_FROM=$readin

readin "是否使用SSL链接，Y：是，N：否" "N"
SSL_V=$readin

#替换配置文件
cp -f kapacitor.conf /etc/kapacitor/kapacitor.conf
sed -i `echo 's#smtp_host#'$MAIL_HOST'#g'` /etc/kapacitor/kapacitor.conf
sed -i `echo 's#smtp_port#'$MAIL_PORT'#g'` /etc/kapacitor/kapacitor.conf
sed -i `echo 's#smtp_user#'$MAIL_USER'#g'` /etc/kapacitor/kapacitor.conf
sed -i `echo 's#smtp_password#'$MAIL_PASSWORD'#g'` /etc/kapacitor/kapacitor.conf
sed -i `echo 's#smtp_from#'$MAIL_FROM'#g'` /etc/kapacitor/kapacitor.conf
if [[ "$SSL_V" = "N" ]]; then
  sed -i 's/no-verify = false/no-verify = true/g' /etc/kapacitor/kapacitor.conf  
fi

#启动服务
service kapacitor start

echo [Notice]服务已安装，服务名influxdb及kapacitor。
