package com.fiberhome.mapps.intergration.session;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.MultipartResolver;

import com.fiberhome.mapps.intergration.security.sso.SsoFilter;
import com.fiberhome.mapps.intergration.security.sso.UserInfo;
import com.fiberhome.mapps.intergration.security.sso.Validator;
import com.rop.config.SystemParameterNames;

/**
 * @Author wangwenquan 2012-12-4
 */
@Component
public class RopSessionFilter implements Filter {
	private final static String SESSION_KEY = "___USER_INFO___";
	private final static String SESSION_ID = "___SESSION_ID___";
	
	private static Logger LOG = LoggerFactory.getLogger(RopSessionFilter.class);
	
	@Autowired
	private MultipartResolver multipartResolver;
	
	@Autowired
	private Validator validator;

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest)request;
		
		LOG.debug("Rop Session Filter worked.");
		
		HttpServletRequest checkRequest = checkMultipart(req);
		HttpSession httpSession = req.getSession();
		
		String sessionId = checkRequest.getParameter(SystemParameterNames.getSessionId());
		UserInfo user = (UserInfo)httpSession.getAttribute(SsoFilter.SESSION_KEY);
					
		// 设置ROP session
		if (user != null) { 
			RopSession session = new RopSession();
			SessionContext.set(session);
			session.setSessionId(sessionId);
			session.setUser(user);
		}
		
		try {
			chain.doFilter(checkRequest, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		SessionContext.clear();
	}

	@Override
	public void destroy() {
	}

	/**
	 * Convert the request into a multipart request, and make multipart resolver
	 * available.
	 * <p>
	 * If no multipart resolver is set, simply use the existing request.
	 * 
	 * @param request
	 *            current HTTP request
	 * @return the processed request (multipart wrapper if necessary)
	 * @see MultipartResolver#resolveMultipart
	 */
	protected HttpServletRequest checkMultipart(HttpServletRequest request) throws MultipartException {
		if (this.multipartResolver != null && this.multipartResolver.isMultipart(request)) {
			if (!(request instanceof MultipartHttpServletRequest)) {
				return this.multipartResolver.resolveMultipart(request);
			}
		}
		// If not returned before: return original request.
		return request;
	}

	public MultipartResolver getMultipartResolver() {
		return multipartResolver;
	}

	public void setMultipartResolver(MultipartResolver multipartResolver) {
		this.multipartResolver = multipartResolver;
	}

	public Validator getValidator() {
		return validator;
	}

	public void setValidator(Validator validator) {
		this.validator = validator;
	}
	
	
}
