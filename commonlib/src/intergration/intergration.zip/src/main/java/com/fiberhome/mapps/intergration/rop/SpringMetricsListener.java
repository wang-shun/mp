package com.fiberhome.mapps.intergration.rop;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.metrics.CounterService;
import org.springframework.boot.actuate.metrics.GaugeService;

import com.rop.RopRequestContext;
import com.rop.event.AfterDoServiceEvent;
import com.rop.event.RopEventListener;

public class SpringMetricsListener implements RopEventListener<AfterDoServiceEvent>{
	@Autowired
	CounterService counterService;	
	
	@Autowired
	GaugeService gaugeService;

	@Override
	public void onRopEvent(AfterDoServiceEvent ropEvent) {
		RopRequestContext ropRequestContext = ropEvent.getRopRequestContext();
		String method = ropRequestContext.getMethod();
		String version = ropRequestContext.getVersion();
		
		String metricName = method + "." + version;
		counterService.increment("meter." + metricName);
		gaugeService.submit("timer." + metricName, ropEvent.getServiceEndTime() - ropEvent.getServiceBeginTime());
		gaugeService.submit("histogram." + metricName, ropEvent.getServiceEndTime() - ropEvent.getServiceBeginTime());
		
	}

	@Override
	public int getOrder() {
		// TODO Auto-generated method stub
		return 0;
	}

}
