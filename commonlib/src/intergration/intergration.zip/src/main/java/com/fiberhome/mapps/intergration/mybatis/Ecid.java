package com.fiberhome.mapps.intergration.mybatis;

public @interface Ecid {

}
