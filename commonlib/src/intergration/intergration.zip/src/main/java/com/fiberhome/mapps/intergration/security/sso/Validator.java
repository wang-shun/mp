package com.fiberhome.mapps.intergration.security.sso;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.fiberhome.mos.core.openapi.rop.client.RopClient;
import com.fiberhome.mos.core.openapi.rop.client.RopClientException;

@Component
@ConfigurationProperties(prefix = "mplus.sso")
public class Validator {
	private static final Logger LOG = LoggerFactory.getLogger(Validator.class);
	
	private static final String SSOAPI_METHOD = "mobileark.ssocheck";
	private static final String SSOAPI_VERSION = "1.3";
	private static final String FORMAT = "json";
	
	private static final String USERAPI_METHOD = "mobileark.getuser";
	private static final String USERAPI_VERSION = "1.3";

	private String serviceUrl;
	private String appKey = "";
	private String secret = "";

//	@NotNull(message="请检查application.yml, sso.serviceUrl是否正确配置")
	public String getServiceUrl() {
		return serviceUrl;
	}

	public void setServiceUrl(String serviceUrl) {
		this.serviceUrl = serviceUrl;
	}

	public String getAppKey() {
		return appKey;
	}

	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}

	public String getSecret() {
		return secret;
	}

	public void setSecret(String secret) {
		this.secret = secret;
	}
	
	RopClient client;

	public UserInfo validate(String sessionId, boolean bClient, String ecid, String orgId) {
		assert(sessionId != null && sessionId.length() > 0);
		client = new RopClient(serviceUrl, appKey, secret, FORMAT);
		
		try {
			UserInfo user = ssoValidate(sessionId, bClient, ecid, orgId);
			// 补全部门信息
			if (user != null) {
				retriveDeptInfo(sessionId, user);
			}
			LOG.debug("登录用户信息：{}", user);
			return user;
		} catch (RopClientException e) {
			LOG.error("接口调用失败", e);
		}
		return null;
	}

	private UserInfo ssoValidate(String sessionId, boolean bClient, String ecid, String orgId) throws RopClientException {
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("sessionId", sessionId);
		params.put("type", bClient ? "1" : "2");  // 1.终端 2、管理端
		Map<String, Object> response = client.requestForMap(SSOAPI_METHOD, SSOAPI_VERSION, params);
		LOG.debug("SSO校验结果：{}", response);
		
		if (response != null && "0".equals(response.get("resultCode"))) { // 返回码，0：成功，1：无效
			List<Map> orginfo = (List<Map>) response.get("orgInfos");
			Map userinfo = (Map)response.get("userInfo");
			List<String> roles = (List<String>)response.get("roles");
			
			UserInfo user = new UserInfo();
			// 由于mplus所有的第三方接口基本基于loginId来进行处理，故将loginId作为userId处理
			user.setUserId((String)userinfo.get("userUuid"));
//			user.setUserId((String)userinfo.get("loginId"));
			user.setLoginId((String)userinfo.get("loginId"));
			user.setUserName((String)userinfo.get("userName"));
			user.setPhoneNumber((String)userinfo.get("phoneNumber"));
			user.setEmailAddress((String)userinfo.get("emailAddress"));
			
			if (orginfo == null || orginfo.size() == 0) {
				LOG.warn("SSO校验失败，没有机构信息！！");
				return null;
			}
			
			if (bClient) { // 手机端取机构
				Map map = orginfo.get(0);
				user.setEcid((String)map.get("orgCode"));                          
				user.setOrgId((String)map.get("orgUuid"));
				user.setOrgName((String)map.get("orgName"));
			} else { // web端取机构
				for (Map map : orginfo) {
					if (ecid.equals(map.get("orgCode"))) {
						user.setEcid((String)map.get("orgCode"));                          
						user.setOrgId((String)map.get("orgUuid"));
						user.setOrgName((String)map.get("orgName"));
					}
				}
				
				if (user.getEcid() == null) {
					LOG.warn("SSO校验失败，接口返回部门信息中没有ecid为『{}』的机构！！", ecid);
					return null;
				}
			}

			boolean isAdmin = roles != null && (roles.contains("0001") || roles.contains("0002"));
			user.setAdmin(isAdmin);
			
			return user;
		}
		return null;
	}

	/**
	 * 补全部门信息
	 * @param sessionId
	 * @param user
	 * @return
	 * @throws RopClientException 
	 */
	private void retriveDeptInfo(String sessionId, UserInfo user) throws RopClientException {
		assert(user != null);
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("sessionId", sessionId);
		params.put("orgUuid", user.getOrgId());
		params.put("loginIds", user.getLoginId());  // 1.终端 2、管理端
		
		Map<String, Object> response = client.requestForMap(USERAPI_METHOD, USERAPI_VERSION, params);
		LOG.debug("用户信息获取结果：{}", response);
		
		if (response != null && "1".equals(response.get("userSize"))) { // 返回码，0：成功，1：无效
			List<Map> userInfos = (List<Map>) response.get("userInfos");
			if (userInfos != null && userInfos.size() == 1) {
				Map userInfo = userInfos.get(0);
				String deptId = (String)userInfo.get("depUuid");
				String deptFullName = (String)userInfo.get("department");
				String avatarUrl = (String)userInfo.get("avatarUrl");
				String deptOrder = (String)userInfo.get("depOrder");
				
				String deptName = "";
				if (deptFullName != null) {
					deptName = deptFullName.substring(deptFullName.lastIndexOf('/') + 1);
				}
				
				user.setDeptId(deptId);
				user.setDeptName(deptName);
				user.setDeptFullName(deptFullName);
				user.setAvatarUrl(avatarUrl);
				user.setDeptOrder(deptOrder);
			} else {
				LOG.warn("接口返回的部门信息:{}有误, 不能获取部门信息。", userInfos);
			}
		}
	};
}
