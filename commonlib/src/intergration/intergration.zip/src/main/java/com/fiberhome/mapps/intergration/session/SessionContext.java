package com.fiberhome.mapps.intergration.session;

import com.fiberhome.mapps.intergration.security.sso.UserInfo;

public final class SessionContext {
	private final static ThreadLocal<RopSession> SESSION = new ThreadLocal<RopSession>();
	
	public static void set(RopSession session) {
		SESSION.set(session);
	}
	
	public static RopSession get() {
		return SESSION.get();
	}
	
	public static void clear() {
		SESSION.remove();
	}
	
	public static String getUserId() {
		UserInfo user = getUser();
		return user != null ? user.getLoginId() : null;
	}
	
	public static String getUserUuid() {
		UserInfo user = getUser();
		return user != null ? user.getUserId() : null;
	}
	
	public static String getUserName() {
		UserInfo user = getUser();
		return user != null ? user.getUserName() : null;
	}
	
	public static String getEcId() {
		UserInfo user = getUser();
		return user != null ? user.getEcid() : null;
	}
	
	private static UserInfo getUser() {
		RopSession ss =  get();
		if (ss != null) {
			return ss.getUser();
		}
		return null;
	}
	
	public static String getOrgId() {
		UserInfo user = getUser();
		return user != null ? user.getOrgId() : null;
	}
	
	public static boolean isAdmin() {
		UserInfo user = getUser();
		return user != null ? user.isAdmin() : false;
	}
	
	public static String getDeptId() {
		UserInfo user = getUser();
		return user != null ? user.getDeptId() : null;
	}
	
	public static String getDeptName() {
		UserInfo user = getUser();
		return user != null ? user.getDeptName() : null;
	}
	
	public static String getDeptFullName() {
		UserInfo user = getUser();
		return user != null ? user.getDeptFullName() : null;
	}
	
	public static String getDeptOrder() {
		UserInfo user = getUser();
		return user != null ? user.getDeptOrder() : null;
	}
}
