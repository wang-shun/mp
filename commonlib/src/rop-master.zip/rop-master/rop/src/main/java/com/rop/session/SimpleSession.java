/**
 * 版权声明： 版权所有 违者必究 2012
 * 日    期：12-6-21
 */
package com.rop.session;

/**
 *
 * @author 陈雄华
 * @version 1.0
 */
public class SimpleSession extends AbstractSession {
}

