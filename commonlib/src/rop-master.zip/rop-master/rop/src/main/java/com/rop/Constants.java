/**
 * 版权声明： 版权所有 违者必究 2012
 * 日    期：12-6-11
 */
package com.rop;

/**
 * <pre>
 * 功能说明：
 * </pre>
 *
 * @author 陈雄华
 * @version 1.0
 */
public class Constants {

    public static final String UTF8 = "UTF-8";
}

