/**
 * 版权声明： 版权所有 违者必究 2012
 * 日    期：12-6-6
 */
package com.rop;

/**
 * @author : chenxh(quickselect@163.com)
 * @date: 13-11-1
 */
public class CommonConstant {

    public static final String ERROR_TOKEN = "@@$-ERROR_TOKEN$-@@";

    public static final String SESSION_CHANGED = "@@SESSION_CHANGED__";
}
