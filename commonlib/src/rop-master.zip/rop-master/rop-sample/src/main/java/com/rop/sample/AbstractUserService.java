/**
 * Copyright：中软海晟信息科技有限公司 版权所有 违者必究 2014 
 */
package com.rop.sample;

/**
 * @author : chenxh(quickselect@163.com)
 * @date: 14-3-6
 */
public abstract class AbstractUserService implements UserServiceInterface {
}
